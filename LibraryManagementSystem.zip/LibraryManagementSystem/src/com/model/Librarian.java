package com.model;

public class Librarian {
	private static String id;
	private static String password;
	public static String getId() {
		return id;
	}
	public static void setId(String id) {
		Librarian.id = id;
	}
	public static String getPassword() {
		return password;
	}
	public static void setPassword(String password) {
		Librarian.password = password;
	}
	
}
