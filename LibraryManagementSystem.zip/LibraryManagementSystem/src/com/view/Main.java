package com.view;

import java.util.Scanner;

import com.controller.Library;
import com.model.*;

public class Main {
	// static scanner object to access everywhere in the class
	private static Scanner sc = new Scanner(System.in);

	// method to check the password is valid or not
	public static boolean isValidPassword(String pwd) {
		if (pwd.length() < 8 || pwd.contains(" ")) {
			return false;
		} else {
			boolean upper = false, lower = false, number = false, special = false;
			for (int i = 0; i < pwd.length(); i++) {
				char ch = pwd.charAt(i);
				if (ch >= 'a' && ch <= 'z')
					lower = true;
				else if (ch >= 'A' && ch <= 'Z')
					upper = true;
				else if (ch >= '0' && ch <= '9')
					number = true;
				else
					special = true;
			}
			if (lower && upper && number && special)
				return true;
			else
				return false;
		}
	}

	// to create the librarian account
	public static void createLibrarian() {
		System.out.println("Hello Librarian please create your account first");
		System.out.println("Please set your ID :");
		String id = sc.nextLine();
		Librarian.setId(id);
		String pwd;
		do {
			System.out.println("Please set your Password :");
			pwd = sc.nextLine();
			if (isValidPassword(pwd)) {
				Librarian.setPassword(pwd);
			} else {
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				try {
					throw new PasswordNotStrongException("The password is not strong...");
				} catch (PasswordNotStrongException p) {
					p.printStackTrace();
				}
			}
		} while (!isValidPassword(pwd));
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("Librarian account created successfully...");
	}

	// for performing operations with the library
	public static void startLibrary() {
		System.out.println("======================== Welcome to our library ========================");
		String pwd, id, userWish = "No";
		do {
			System.out.println("Provide your Librarian ID :");
			id = sc.nextLine();
			System.out.println("Provide your Librarian Password :");
			pwd = sc.nextLine();
			if (Librarian.getId().equals(id) && Librarian.getPassword().equals(pwd)) {
				do {
					System.out.println("Press 1 to add books.");
					System.out.println("Press 2 to print books details.");
					System.out.println("Press 3 to borrow books.");
					System.out.println("Press 4 to return books.");
					int userChoice = sc.nextInt();
					sc.nextLine();
					switch (userChoice) {
					case 1: {
						System.out.println("Provide the Book Title :");
						String title = sc.nextLine();
						System.out.println("Provide the Book Author's Name :");
						String author = sc.nextLine();
						System.out.println("Provide the Book Price :");
						double price = sc.nextDouble();
						System.out.println("Provide the Book Quantity :");
						int quantity = sc.nextInt();
						Library.addBook(title, author, price, quantity);
						break;
					}
					case 2: {
						Library.printBookDetails();
						break;
					}
					case 3: {
						System.out.println("Provide the Book Title :");
						String title = sc.nextLine();
						System.out.println("Provide the Book Author's Name :");
						String author = sc.nextLine();
						System.out.println("Provide the Book Quantity :");
						int quantity = sc.nextInt();
						Library.borrowBook(title, author, quantity);
						break;
					}
					case 4: {
						System.out.println("Provide the Book Title :");
						String title = sc.nextLine();
						System.out.println("Provide the Book Author's Name :");
						String author = sc.nextLine();
						System.out.println("Provide the Book Quantity :");
						int quantity = sc.nextInt();
						Library.returnBook(title, author, quantity);
						break;
					}
					default:
						System.out.println("Invalid Input");
					}
					System.out.println("If you want to continue again type \"Yes\"");
					userWish = sc.next();
				} while (userWish.equalsIgnoreCase("Yes"));
			} else {
				System.out.println("Invalid ID or Password..");
			}
		} while (!(Librarian.getId().equals(id) && Librarian.getPassword().equals(pwd)));
	}

	// to perform operation with the Library users
	public static void userAction() {
		String userWish = "No";
		do {
			System.out.println("Press 1 for adding an user.");
			System.out.println("Press 2 for printing the user details.");
			int userChoice = sc.nextInt();
			sc.nextLine();
			switch (userChoice) {
			case 1: {
				System.out.println("Provide the user name :");
				String name = sc.nextLine();
				System.out.println("Provide the user phone number");
				long phone = sc.nextLong();
				Library.addUser(name, phone);
				break;
			}
			case 2: {
				Library.printUserDetails();
				break;
			}
			default: {
				System.out.println("Invalid input");
				break;
			}
			}
			System.out.println("If you want to continue again type \"Yes\"");
			userWish = sc.next();
		} while (userWish.equalsIgnoreCase("yes"));
	}

	// main method to control everything
	public static void main(String[] args) {
		createLibrarian();
		userAction();
		startLibrary();
		System.out.println("Thank you for giving me this oppurtunity.");
	}
}
